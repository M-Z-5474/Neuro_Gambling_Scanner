import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'appfeatures//home_screen.dart';
import 'appfeatures//riskanalysis_screen.dart';
import 'appfeatures//reports_screen.dart';
import 'appfeatures//interventions_screen.dart';
import 'appfeatures/educational_module/categories_screen.dart';
import 'appfeatures/profile_screen.dart';
import 'appfeatures//settings_screen.dart';
import 'appfeatures/gambling_info_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Neuro Gambling Scanner',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',  // Start from Splash Screen
      routes: {
        '/': (context) => const SplashScreen(),  // First screen
        '/login': (context) => const LoginScreen(),  // Move to Login Screen after Splash
        '/home': (context) => HomeScreen(),  // Move to Home after Login
        '/risk_analysis': (context) => const RiskAnalysisScreen(),
        '/reports': (context) => const ReportsScreen(),
        '/interventions': (context) => const InterventionsScreen(),
        '/education': (context) => const CategoriesScreen(),
        // '/education': (context) => const GamblingInfoScreen(),
        '/profile': (context) => const ProfileScreen(),
        '/settings': (context) => const SettingsScreen(),
      },
    );
  }
}
