import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200], // Light theme
      appBar: AppBar(
        title: Text("Neuro Gambling Scanner",
            style: GoogleFonts.merriweather(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: Colors.blue,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 🔹 Profile Section
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 6,
              color: Colors.white,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundImage: AssetImage('assets/user.png'), // Replace with dynamic image
                  radius: 30,
                ),
                title: Text("Hello, Zain!",
                    style: GoogleFonts.merriweather(
                        fontSize: 20, fontWeight: FontWeight.bold)),
                subtitle: Text("Risk Level: Moderate",
                    style: GoogleFonts.merriweather(
                        color: Colors.orange, fontWeight: FontWeight.w600)),
              ),
            ),

            // SizedBox(height: 20),
            //
            // // 🔹 Quick Stats Section
            // Row(
            //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //   children: [
            //     _buildStatCard("Risk Score", "75%", Colors.red, Icons.warning),
            //     _buildStatCard("Recent Alerts", "3", Colors.orange, Icons.notifications_active),
            //     _buildStatCard("Safe Days", "10", Colors.green, Icons.verified),
            //   ],
            // ),

            SizedBox(height: 20),

            // 🔹 Navigation Grid
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                children: [
                  _buildNavButton(context, "Risk Analysis", Icons.analytics, Colors.red, "/risk_analysis"),
                  _buildNavButton(context, "Reports", Icons.bar_chart, Colors.blue, "/reports"),
                  _buildNavButton(context, "Interventions", Icons.psychology, Colors.green, "/interventions"),
                  _buildNavButton(context, "Education", Icons.school, Colors.orange, "/education"),
                  _buildNavButton(context, "Profile", Icons.person, Colors.purple, "/profile"),
                  _buildNavButton(context, "Settings", Icons.settings, Colors.grey, "/settings"),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 📊 Improved Stat Cards with Icons
  Widget _buildStatCard(String title, String value, Color color, IconData icon) {
    return Expanded(
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 6,
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(10.0),//16
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 28, color: color),
              SizedBox(height: 8),
              Text(title, style: GoogleFonts.merriweather(fontSize: 14, fontWeight: FontWeight.bold)),
              SizedBox(height: 5),
              Text(value,
                  style: GoogleFonts.merriweather(
                      fontSize: 18, fontWeight: FontWeight.bold, color: color)),
            ],
          ),
        ),
      ),
    );
  }

  // 🔗 Improved Navigation Buttons
  Widget _buildNavButton(BuildContext context, String title, IconData icon, Color color, String route) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 6,
        padding: EdgeInsets.all(16),
      ),
      onPressed: () {
        Navigator.pushNamed(context, route);
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 40, color: color),
          SizedBox(height: 8),
          Text(title,
              textAlign: TextAlign.center,
              style: GoogleFonts.merriweather(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.black)),
        ],
      ),
    );
  }
}
