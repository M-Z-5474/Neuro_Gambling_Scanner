import 'package:flutter/material.dart';

class InterventionsScreen extends StatelessWidget {
  const InterventionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Interventions")),
      body: const Center(child: Text("Interventions Screen")),
    );
  }
}
