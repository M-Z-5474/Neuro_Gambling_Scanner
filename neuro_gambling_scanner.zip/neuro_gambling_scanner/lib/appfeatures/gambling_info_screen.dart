import 'package:flutter/material.dart';
import 'home_screen.dart'; // Import the Home Screen

class GamblingInfoScreen extends StatefulWidget {
  const GamblingInfoScreen({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _GamblingInfoScreenState createState() => _GamblingInfoScreenState();
}

class _GamblingInfoScreenState extends State<GamblingInfoScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  // List of Questions and Answers
  final List<Map<String, String>> questions = [
    {
      "question": "What Is Gambling Addiction?",
      "answer": "Gambling addiction, also known as compulsive gambling or gambling disorder, is a behavioral condition in which an individual feels an uncontrollable urge to gamble, despite facing negative consequences in their personal, financial, or professional life. This addiction is classified as an impulse-control disorder and is often compared to substance addiction because of the similar effects it has on the brain’s reward system. People with gambling addiction struggle to stop or reduce their gambling activities, even when they are aware of the harm it is causing. The impact of gambling addiction on mental health can be severe, as it often leads to a cycle of emotional distress, financial difficulties, and social problems. One of the most common effects is chronic stress and anxiety. People addicted to gambling often experience extreme worry about their financial losses, outstanding debts, and the potential consequences of their gambling behavior. This constant stress can affect their ability to focus, make rational decisions, and maintain a sense of stability in their lives. Additionally, gambling addiction can contribute to depression, as individuals frequently feel a sense of guilt and regret after losing money. They may experience hopelessness, believing they will never be able to recover from their financial problems, leading to deep emotional despair. In some cases, this can result in a loss of motivation and interest in daily activities, further isolating them from family, friends, and professional responsibilities. Another significant impact is mood instability, where individuals experience emotional highs and lows based on their gambling outcomes. Winning a bet may provide a temporary sense of excitement and euphoria, but losing often leads to frustration, sadness, and anger. Over time, these fluctuations can result in emotional exhaustion and a sense of helplessness. Perhaps the most alarming consequence of gambling addiction is its link to suicidal thoughts and self-harm. The overwhelming financial burden, relationship conflicts, and feelings of failure can push individuals to a state of extreme distress. Some may feel there is no escape from their problems, leading them to consider self-harm or suicidal actions. Studies have shown that gambling addicts are at a significantly higher risk of suicidal ideation compared to the general population, highlighting the urgent need for mental health support and intervention. Overall, gambling addiction is not just a financial issue—it is a serious mental health disorder that can lead to emotional turmoil, severe anxiety, and, in extreme cases, suicidal tendencies. Seeking professional help, joining support groups, and developing coping strategies are essential steps in addressing this addiction and rebuilding a healthy, stable life.",
    },
    {
      "question": "Signs Of Gambling Addiction",
      "answer": "Signs include an urge to gamble with increasing amounts of money, lying about gambling, chasing losses, neglecting responsibilities, and experiencing guilt or anxiety."
    },
    {
      "question": "How Gambling Addiction Can Affect Your Life?",
      "answer": "Gambling addiction leads to financial debt, broken relationships, anxiety, depression, and even job loss. Without support, it becomes a difficult cycle to break."
    },
    {
      "question": "Effective Treatments For Gambling Addiction",
      "answer": "Treatments include therapy, support groups, and self-help strategies. Cognitive Behavioral Therapy (CBT) helps identify triggers and develop coping mechanisms."
    },
    {
      "question": "Examples Of Treatment Using CBT",
      "answer": "CBT helps by identifying triggers, restructuring gambling-related thoughts, and developing alternative coping strategies like exercise or meditation."
    },
    {
      "question": "Approaching A Loved One",
      "answer": "Approaching a loved one about their gambling addiction requires honesty, courage, and understanding. Offer support and encourage professional help."
    },
    {
      "question": "Statistics Regarding Gambling",
      "answer": "Around 1-3% of the world's population struggles with gambling addiction. Adolescents are 2-3 times more likely to develop gambling issues than adults."
    },
    {
      "question": "Summary",
      "answer": "Recovery from gambling addiction is possible with the right mindset and support system. Professional counseling and self-help tools are highly effective."
    }
  ];

  // Function to navigate to next page
  void _nextPage() {
    if (_currentPage < questions.length - 1) {
      setState(() {
        _currentPage++;
      });
      _pageController.nextPage(duration: Duration(milliseconds: 300), curve: Curves.easeInOut);
    }
  }

  // Function to navigate to previous page
  void _prevPage() {
    if (_currentPage > 0) {
      setState(() {
        _currentPage--;
      });
      _pageController.previousPage(duration: Duration(milliseconds: 300), curve: Curves.easeInOut);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Gambling Awareness")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Progress Indicator
            Text(
              "Question ${_currentPage + 1} of ${questions.length}",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blueAccent),
            ),
            SizedBox(height: 10),
            LinearProgressIndicator(
              value: (_currentPage + 1) / questions.length,
              backgroundColor: Colors.grey[300],
              color: Colors.blueAccent,
            ),
            SizedBox(height: 20),

            // Question and Answer Display
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                onPageChanged: (index) {
                  setState(() {
                    _currentPage = index;
                  });
                },
                itemCount: questions.length,
                itemBuilder: (context, index) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        questions[index]["question"]!,
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.blueAccent),
                      ),
                      SizedBox(height: 10),
                      Text(
                        questions[index]["answer"]!,
                        style: TextStyle(fontSize: 16, color: Colors.black87),
                      ),
                    ],
                  );
                },
              ),
            ),

            // Navigation Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: _currentPage > 0 ? _prevPage : null,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
                  child: Text("Previous", style: TextStyle(color: Colors.white)),
                ),
                _currentPage < questions.length - 1
                    ? ElevatedButton(
                  onPressed: _nextPage,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
                  child: Text("Next", style: TextStyle(color: Colors.white)),
                )
                    : ElevatedButton(
                  onPressed: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (context) => HomeScreen(),
                      ),
                          (route) => false, // Remove all previous routes from the stack
                    );
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  child: Text("Back to Home", style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

