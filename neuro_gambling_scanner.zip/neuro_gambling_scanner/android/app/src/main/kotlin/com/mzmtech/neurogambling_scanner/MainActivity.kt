package com.mzmtech.neurogambling_scanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
